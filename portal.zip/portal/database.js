// var mysql = require('mysql');
// var con;

// function connectDatabase() {
//     if (!con) {
//         con = mysql.createPool({
//             /*
//             host: 'localhost',
//             user: 'root',
//             password: '123456',
//             database: 'lms_database'
// */

//             host: 'expertscommunication.net',
//             user: 'expertsc_lms',
//             password: 'Mehr@nKhi2',
//             database: 'expertsc_lms'

//         });

//         con.getConnection((err) => {
//             if (err) {
//                 console.log('Failed to establish connection with database. Error: ' + JSON.stringify(err));
//             }
//         })
//     }
//     return con;
// }

// module.exports = connectDatabase();
