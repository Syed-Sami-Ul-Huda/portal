var path = require("path");
var express = require("express");
var bodyparser = require("body-parser");

var dashboard = require("./routes/dashboard");
var home = require("./routes/home");

var app = express();
app.use(express.static(path.join(__dirname, "assets")));
app.use(bodyparser.urlencoded({ extended: false }));

app.use("/customers_dashboard", dashboard);
app.use("/", home);

app.get("*", function (req, res) {
  res.status(404).send("404 Not found");
});

app.listen(8000);
