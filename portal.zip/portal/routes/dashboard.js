var path = require("path");
var express = require("express");
var bodyparser = require("body-parser");

var database = require("../database");

var router = express.Router();
router.use(express.static(path.join(__dirname, "assets")));
router.use(bodyparser.json());
router.use(bodyparser.urlencoded({ extended: true }));

router
  .route("/dashboard")
  .get((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard/dashboard.html")
    );
  })
  .post((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard/dashboard.html")
    );
  });

router
  .route("/user")
  .get((request, response) => {
    response.status(200);
    response.sendFile(path.join(__dirname, "../customers_dashboard/user.html"));
  })
  .post((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard//user.html")
    );
  });

router
  .route("/tables")
  .get((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard//tables.html")
    );
  })
  .post((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard//tables.html")
    );
  });

router
  .route("/typography")
  .get((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard//typography.html")
    );
  })
  .post((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard//typography.html")
    );
  });

router
  .route("/icons")
  .get((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard//icons.html")
    );
  })
  .post((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard//icons.html")
    );
  });

router
  .route("/map")
  .get((request, response) => {
    response.status(200);
    response.sendFile(path.join(__dirname, "../customers_dashboard//map.html"));
  })
  .post((request, response) => {
    response.status(200);
    response.sendFile(path.join(__dirname, "../customers_dashboard//map.html"));
  });

router
  .route("/notifications")
  .get((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard//notifications.html")
    );
  })
  .post((request, response) => {
    response.status(200);
    response.sendFile(
      path.join(__dirname, "../customers_dashboard//notifications.html")
    );
  });

router
  .route("/rtl")
  .get((request, response) => {
    response.status(200);
    response.sendFile(path.join(__dirname, "../customers_dashboard//rtl.html"));
  })
  .post((request, response) => {
    response.status(200);
    response.sendFile(path.join(__dirname, "../customers_dashboard//rtl.html"));
  });

module.exports = router;
