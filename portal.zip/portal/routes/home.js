var path = require("path");
var express = require("express");
var bodyparser = require("body-parser");

var con = require("../database");

var router = express.Router();
router.use(express.static(path.join(__dirname, "assets")));
router.use(bodyparser.json());
router.use(bodyparser.urlencoded({ extended: true }));

router
  .route("/")
  .get((request, response) => {
    response.status(200);
    response.sendFile(path.join(__dirname, "../home/signin.html"));
  })
  .post((request, response) => {
    response.status(200);
    response.sendFile(path.join(__dirname, "../home/signin.html"));
  });

router
  .route("/signin")
  .get((request, response) => {
    response.status(200);
    response.sendFile(path.join(__dirname, "../home/signin.html"));
  })
  .post((req, res) => {
    let query =
      "SELECT `user_id` FROM `login_credentials` WHERE `user_name` = '" +
      req.body.username +
      "' AND `user_password` = '" +
      req.body.password +
      "'";
    con.query(query, (err, result) => {
      if (err) {
        throw err;
      } else {
        if (result.length > 0) {
          res.status(200);
          res.sendFile(
            path.join(__dirname, "../cutomers_dashboard/dashboard.html")
          );
        } else {
          res.send(
            "Username or password you entered was found to be incorrect."
          );
        }
      }
    });
  });

router
  .route("/signup")
  .get((request, response) => {
    response.status(200);
    response.sendFile(path.join(__dirname, "../home/signup.html"));
  })
  .post((req, res) => {
    let current_date = new Date(Date.now());
    let birthday = new Date(req.body.birthday);
    var user_name;
    let query =
      "INSERT INTO `student_credentials` (`student_name`, `student_birthday`, `student_gender`, `student_class`, `student_phone`, `id_creation_date`) VALUES ('" +
      req.body.name +
      "','" +
      (birthday.getFullYear() +
        "-" +
        (birthday.getMonth() + 1) +
        "-" +
        birthday.getDate()) +
      "','" +
      req.body.gender +
      "','" +
      req.body.class +
      "'," +
      req.body.mobile_number +
      ", '" +
      (current_date.getFullYear() +
        "-" +
        (current_date.getMonth() + 1) +
        "-" +
        current_date.getDate()) +
      "')";
    con.query(query, (err, result) => {
      let select_user =
        "SELECT `student_id` FROM `student_credentials` WHERE `student_name` = '" +
        req.body.name +
        "' and `student_phone` = " +
        req.body.mobile_number;
      con.query(select_user, (err, result) => {
        user_name = (req.body.name + "_" + result[0].student_id)
          .replace(/\s+/g, "_")
          .toLowerCase();
        let create_user =
          "INSERT INTO `login_credentials`(`user_id`, `user_name`, `user_password`) VALUES (" +
          result[0].student_id +
          ", '" +
          user_name +
          "', '" +
          req.body.password +
          "')"; //await bcrypt.hash(req.body.password, 10)
        con.query(create_user, (err, result) => {
          res.send(
            "Successfully created your ID.\nUse " +
              user_name +
              " as username and give your password to login.\nWe're working on this portal and hope to serve you ASAP.\nFor suggestions feel free to talk to your administration. -Regards Bilal Ahmed"
          );
        });
      });
    });
  });

module.exports = router;
